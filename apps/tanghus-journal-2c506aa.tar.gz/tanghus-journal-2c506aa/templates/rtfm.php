<ul style="margin: 2em; font-size: 1.4em; line-spacing: 2em;">
<?php 
foreach($_['errors'] as $error) { ?>
    <li><?php echo $error; ?></li>
<?php } ?>
</ul>

